package com.cherry.TestCases;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cherry.Pages.SignInPage;
import com.cherry.TestBase.TestBase;

public class SignInPageTest extends TestBase{
	
SignInPage sp = new SignInPage();
	
	public static XSSFWorkbook workbook;
    public static XSSFSheet worksheet;
    public static DataFormatter formatter= new DataFormatter();
    public static String file_location = System.getProperty("user.dir")+"\\src\\main\\java\\com\\cherry\\Util\\CustomerDetails.xlsx";
    static String SheetName= "SignIn Page";
	
	public SignInPageTest() {
		super();
	}

	@BeforeMethod
	public void setUp() throws Exception {
		initialization();

		
		
	}
	 @DataProvider
	    public static Object[][] ReadCell() throws IOException
	    {
	    FileInputStream fileInputStream= new FileInputStream(file_location); //Excel sheet file location get mentioned here
	        workbook = new XSSFWorkbook (fileInputStream); //get my workbook 
	        worksheet=workbook.getSheet(SheetName);// get my sheet from workbook
	        XSSFRow Row=worksheet.getRow(0);     //get my Row which start from 0   
	     
	        int RowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
	        int ColNum= Row.getLastCellNum(); // get last ColNum 
	        
	        System.out.println("Total number of rows:" +RowNum);
	         
	        Object Data[][]= new Object[RowNum-1][ColNum]; // pass my  count data in array
	         
	            for(int i=0; i<RowNum-1; i++) //Loop work for Rows
	            {  
	                XSSFRow row= worksheet.getRow(i+1);
	                 
	                for (int j=0; j<ColNum; j++) //Loop work for colNum
	                {
	                    if(row==null)
	                        Data[i][j]= "";
	                    else
	                    {
	                        XSSFCell cell= row.getCell(j);
	                        if(cell==null)
	                            Data[i][j]= ""; //if it get Null value it pass no data 
	                        else
	                        {
	                            String value=formatter.formatCellValue(cell);
	                            Data[i][j]=value; //This formatter get my all values as string i.e integer, float all type data value
	                        }
	                    }
	                }
	            }
	 
	        return Data;
	    }
	    
	@Test(dataProvider="ReadCell")
	public void ValidateRegistrationPage(String Email, String password) throws Exception {
		sp.ClickOnSignLinkButton();
		sp.EnterEmailId(Email);
		sp.EnterPassword(password);
		sp.ClickOnSignInButton();
		
	}
	@AfterMethod
    public static void endSelenium(){
        driver.close();
        try{
            driver.quit();
        }catch (Exception e){
            System.out.println("Browser closed already, " +
                            "did not need to quit after all");
            e.printStackTrace();
        }
    }

}



