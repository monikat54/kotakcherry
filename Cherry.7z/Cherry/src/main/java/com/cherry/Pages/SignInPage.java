package com.cherry.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cherry.TestBase.TestBase;

public class SignInPage extends TestBase{
	
	@FindBy(xpath ="//span[text()='Sign in']")
	WebElement SignInLink;
	
	@FindBy(className = "mat-form-field-infix ng-tns-c124-0")
	WebElement Emailid;
	
	@FindBy(className = "mat-form-field-infix ng-tns-c124-1")
	WebElement Password;
	
	@FindBy(xpath = "//span[text()=' Sign in']")
	WebElement SignInButton;
	
	
	public SignInPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void ClickOnSignLinkButton() {
		SignInLink.click();
	}
	public void EnterEmailId(String Email) {
		Emailid.sendKeys(Email);
	}
	public void EnterPassword(String password) {
		Password.sendKeys(password);
	}
	public void ClickOnSignInButton() {
		SignInButton.click();
	}


}
