package com.cherry.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cherry.TestBase.TestBase;

public class RegistrationPage extends TestBase{
	
	@FindBy(xpath ="//span[text()='Register']")
	WebElement RegisterButton;
	
	@FindBy(xpath = "//span[text()='Accept']")
	WebElement AcceptButton;
	
	@FindBy(className = "mat-form-field-infix ng-tns-c124-2")
	WebElement MobileNumber;
	
	@FindBy(className = "mat-form-field-infix ng-tns-c124-3")
	WebElement EmailId;
	
	@FindBy(className = "mat-form-field-infix ng-tns-c124-4")
	WebElement PanNumber;
	
	@FindBy(linkText = "assets/images/ic_expand_more.svg")
	WebElement DateOfBirth;
	
	@FindBy(className = "mat-checkbox-input cdk-visually-hidden")
	WebElement Checkbox;
	
	
	public RegistrationPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void EnterMobileNumber(String Mobilenumber) {
		MobileNumber.sendKeys(Mobilenumber);
	}
	public void EnterEmailId(String Emailid) {
		EmailId.sendKeys(Emailid);
	}
	public void ClickOnRegisterButton() {
		RegisterButton.click();
	}
	public void ClickOnAcceptButton() {
		AcceptButton.click();
	}
	public void EnterPanCard(String Pancard) {
		PanNumber.sendKeys(Pancard);
	}
	public void EnterDOB(String DOB) {
		DateOfBirth.sendKeys(DOB);
	}
	public void ClickOnCheckBox() {
		Checkbox.click();
	}
	

}
