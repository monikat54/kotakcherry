package com.cherry.Util;

public class TestUtil {
	
	
	public static long PAGE_LOAD_TIMEOUT = 60;
	public static long IMPLICIT_WAIT = 90;

}
